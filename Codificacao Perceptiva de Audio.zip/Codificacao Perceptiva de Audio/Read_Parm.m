function [Akr, Phikr, Xir, IndMax] = Read_Parm(structBook, n)

Akr=structBook(n,1);
Phikr=structBook(n,2);
Xir=structBook(n,3);
IndMax=structBook(n,4);

   
end