
function [DFlags, DTonal_list, DNon_tonal_list] = DEC_M(X, Tonal_list, Non_tonal_list, Flags, TqN)

Common;

%disp('Decimation_TESTE')


DFlags = Flags; % Flags after decimation


% Tonal or non-tonal components are not considered if lower than
% the absolute threshold of hearing found in TH(:, ATH).

% Non tonal case
DNon_tonal_list = [];
if not(isempty(Non_tonal_list))
	for i = 1:length(Non_tonal_list(:, 1)),
	   k = Non_tonal_list(i, INDEX);
	   %if (k > length(Map))
	   %   DFlags(k) = IRRELEVANT;
	   %else
	   if (Non_tonal_list(i, SPL) < TqN(1,k))
	   	DFlags(k) = IRRELEVANT;
		else
		   DNon_tonal_list = [DNon_tonal_list; Non_tonal_list(i, :)];
	   end
	   %end
	end

end

% Tonal case (first part)
DTonal_list = [];
if not(isempty(Tonal_list))
	for i = 1:length(Tonal_list(:, 1)),
	    k = Tonal_list(i, INDEX);
         if (Tonal_list(i, SPL) < (TqN(1,k))) % Observar o deslocamento de -12
		    DFlags(k) = IRRELEVANT;
         else
		    DTonal_list = [DTonal_list; Tonal_list(i, :)];
	end
	   
end

end

% Eliminate tonal components that are less than one half of
% critical band width from a neighbouring component.
% (second part of tonal case)
if not(isempty(DTonal_list))
	i = 1;
	while (i < length(DTonal_list(:, 1))),
	     k      = DTonal_list(i, INDEX);
	     k_next = DTonal_list(i + 1, INDEX);
		 %***********if (TH(Map(k_next), BARK) - TH(Map(k), BARK) < 0.5)  
         if ((TqN(1,k_next)) - (TqN(1,k)) < 0.5)            % Observar o deslocamento de -12
		   if (DTonal_list(i, SPL) < DTonal_list(i + 1, SPL))
               
	           DTonal_list = DTonal_list([1:i - 1, i + 1:length(DTonal_list(:, 1))], :);
               
	           DFlags(k) = IRRELEVANT;
               
           else
               
	         DTonal_list = DTonal_list([1:i,i + 2:length(DTonal_list(:, 1))], :);
             
	         DFlags(k_next) = IRRELEVANT;
             
		   end
	   end
	   i = i + 1;
	end

end

