clc;
clear all;
disp('In�cio Graficos ');


load('result_decomp');
Audio_Decomposto = result_decomp;
[Audio_Decompostorow,Audio_Decompostocol] = size(Audio_Decomposto)


[z,Fs] = audioread('pianoA3.wav');           %Retorna a taxa de amostragem (Fs) em Hertz usada para codificar os dados do arquivo

load('RecompQuantizado');
RecompQuantizado = y1final;

load('RecompNaoQuantizado');
RecompNaoQuantizado = yfinal;


load('Initial_Parm');
PARAMETROS_INICIAIS = Initial_Parm;


load('IterPorBloco');
ITERACAO = Numer_Blocos_Itera;
[ITERACAOrow,ITERACAOcol] = size(ITERACAO);


N = Initial_Parm(1,1)
M = Initial_Parm(1,2);
N_hop = Initial_Parm(1,3)
dB = Initial_Parm(1,4);
MRT = Initial_Parm(1,5);
BA = Initial_Parm(1,6);
NBA = BA;
%NBA = 3
BPh = Initial_Parm(1,7);
NBPh = BPh;
%NBPh = 3
s = Initial_Parm(1,8);


Number_Of_Block =  floor(length(z)/N_hop) %Numero de blocos arredondado para baixo, sem os complementos de zeros

w = hanning(N);
[row_w ,col_w] = size(w)


for jBlock = 1:(Number_Of_Block-1)

 a = N_hop*(jBlock-1)+1;
 b = a+N-1;

 
 NITER = ITERACAO(jBlock,1);
  
Origial = z(a:b);
[row_Origial ,col_Origial] = size(Origial);

Origial_Janelado = (w.*Origial)';
[row_Origial_Janelado ,col_Origial_Janelado] = size(Origial_Janelado);

Quantizado = RecompQuantizado(a:b);
[row_Quantizado ,col_Quantizado] = size(Quantizado);


NaoQuantizado = RecompNaoQuantizado(a:b);

[EQM,NumberofBits] = MSE_NumberofBits(Origial_Janelado,Quantizado,BA,BPh,M,NITER);
DADOS_QUANTIZACAO(jBlock,:) = [EQM NumberofBits jBlock];
%DADOS_QUANTIZACAO(jBlock-1,:) = [EQM NumberofBits jBlock];

close all


%**************************************************************************
                        figure(jBlock)
                        
                        subplot(2,1,1)
                        plot(Origial, 'k-','LineWidth',2);
                        hold on
                        plot(Quantizado, '-.','LineWidth',2)
                        legend('Origial','Audio Reconstruido Quantizado');
                        title(['Sinal Temporal Janelado do Bloco' num2str(jBlock)])
                        hold off
     
                       subplot(2,1,2)
                       stem(DADOS_QUANTIZACAO(:,2),DADOS_QUANTIZACAO(:,1), 'r:','o','LineWidth',1)
                       title(['Erro Quadratico Medio X Numero Total de Bits' num2str(jBlock)])
                       xlabel('Total de Bits')
                       ylabel('Erro')
                       drawnow
%                         pause
    
end

[EQM,NumberofBits] = MSE_NumberofBits(z,zeros(size(z)),BA,BPh,M,0);
DADOS_QUANTIZACAO(jBlock+1,:) = [EQM NumberofBits jBlock+1];

                        figure(jBlock+1)
                        
                       stem(DADOS_QUANTIZACAO(:,2),DADOS_QUANTIZACAO(:,1), 'r:','o','LineWidth',1)
                       title(['Erro Quadratico Medio X Numero Total de Bits' num2str(jBlock+1)])
                       xlabel('Total de Bits')
                       ylabel('Erro')
                       drawnow

                       pause


save 'DADOS_QUANTIZACAO.mat' DADOS_QUANTIZACAO;

                       
                       load('AkSave');
AMPLITUDES_MAX_MIN = AkSave;

load('PhikrSave');
FASES_MAX_MIN = PhikrSave;


load('PHIKRQUANTENAO');
PHIKRSAVE = PHIKRQUANTENAO;

%load('DADOSQUANTIZACAO');
%DADOS_QUANTIZ = DADOS_QUANTIZACAO;

PHIKRNQ = [];
PHIKRQUANT = [];


for kBlock = 1:(Audio_Decompostocol-1);
    disp(['Bloco: ' num2str(kBlock)]);
    structBook = Audio_Decomposto{1,kBlock};
    
    PHIKRBook = PHIKRSAVE{1,kBlock};
    
   
    figure(kBlock)
    stem(PHIKRBook(:,1), 'k-.','s','LineWidth',1)
    hold on
    stem(PHIKRBook(:,2), 'r--','x','LineWidth',1)
    legend('Fase Nao Quantizada','Fase Quantizada');
    title(['Fase Nao Quantizada Vs Fase Quantizada do bloco_ ' num2str(kBlock)])
    grid
    hold off
    drawnow
   
  
    PHIKRNQ =[PHIKRNQ; PHIKRBook(:,1)];    
    PHIKRQUANT =[PHIKRQUANT; PHIKRBook(:,2)];    
    
end

figure(kBlock+1);
plot(AMPLITUDES_MAX_MIN(:,1), 'k-','LineWidth',2)
hold on
plot(AMPLITUDES_MAX_MIN(:,2), 'r-','LineWidth',2)
legend('Amplitude Maxima','Amplitude Minima');
title(['Amplitude Maxima Vs Amplitude Minima'])
grid
hold off

Valor_Ampli_Max = max(AMPLITUDES_MAX_MIN(:,1))

figure(kBlock+2);
plot((AMPLITUDES_MAX_MIN(:,1)/Valor_Ampli_Max), 'k-','LineWidth',2)
hold on
plot((AMPLITUDES_MAX_MIN(:,2)/Valor_Ampli_Max), 'r-','LineWidth',2)
legend('Amplitude Maxima Normalizada','Amplitude Minima Normalizada');
title(['Amplitude Maxima Normalizada Vs Amplitude Minima Normalizada'])
grid
hold off

figure(kBlock+3);
plot(FASES_MAX_MIN(:,1), 'k-','LineWidth',2)
hold on
plot(FASES_MAX_MIN(:,2), 'r-','LineWidth',2)
legend('Fase Maxima','Fase Minima');
title(['Fase Maxima Vs Fase Minima'])
grid
hold off

figure(kBlock+4);
histogram(PHIKRNQ);
legend('Fase n�o quantizada');
title(['Fase n�o quantizada'])
grid

figure(kBlock+5);
histogram(PHIKRQUANT);
legend('Fase Quantizada');
title(['Fase Quantizada'])
grid

% figure(kBlock+6);
% stem(DADOS_QUANTIZ(:,2),DADOS_QUANTIZ(:,1), 'r:','o','LineWidth',1)
% legend('NUMERO DE BITS' , 'ERRO QUADRATICO MEDIO');
% title(['NUMERO DE BITS  x ERRO QUADRATICO MEDIO'])
% grid
% 
% figure(kBlock+7);
% stem(DADOS_QUANTIZ(:,2),(DADOS_QUANTIZ(:,1)/max(DADOS_QUANTIZ(:,1))), 'b:','x','LineWidth',1)
% legend('NUMERO DE BITS' , 'ERRO QUADRATICO MEDIO NORMALIZADOR');
% title(['NUMERO DE BITS  x ERRO QUADRATICO MEDIO NORMALIZADO'])
% grid

disp('Final Graficos ');
