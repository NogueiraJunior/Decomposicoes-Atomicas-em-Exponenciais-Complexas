clc
clear all
close all
format long

load('THETA_BITS')
Parametros_Escolhidos = THETA_BITS;
[Parametros_Escolhidos_ROW, Parametros_Escolhidos_COL] = size(Parametros_Escolhidos)

CHOOSE = zeros(Parametros_Escolhidos_COL,4);

Parametros_IN = Parametros_Escolhidos{1,3}
PRIMEIROS_THETAS = radtodeg(Parametros_IN(:,3))


load('All_Theta')
All_Thetas_Rad = All_Theta;
Todo_Thetas_Deg = sort(radtodeg(All_Thetas_Rad))
[Todo_Thetas_Deg_ROW, Todo_Thetas_Deg_COL] = size(Todo_Thetas_Deg)

%Todo_Thetas_Deg_Arre = round(Todo_Thetas_Deg,3)
%Todo_Thetas_Deg_Arre = round(Todo_Thetas_Deg,2)
%Todo_Thetas_Deg_Arre = round(Todo_Thetas_Deg,1)
Todo_Thetas_Deg_Arre = round(Todo_Thetas_Deg)

Todo_Thetas_Deg_Arre_Unico = unique(Todo_Thetas_Deg_Arre)

[Todo_Thetas_Deg_Arre_Unico_ROW, Todo_Thetas_Deg_Arre_Unico_COL] = size(Todo_Thetas_Deg_Arre_Unico)


 disp('Entre o angulo desejada para a quantizacao uniforme, em Graus');
 Theta_Inicial = input('Theta Escolhido = ');
 disp(' ')
Theta_Inicial_Rad = degtorad(Theta_Inicial)
%CurvaOP = [CurvaOP;RMSEk RBk ThetaMin RBAk RPhk];

for k = 3:Parametros_Escolhidos_COL
   
    format long
    Delt_Theta = []
    
    Parametros = Parametros_Escolhidos{1,k}
    [Parametros_ROW, Parametros_COL] = size(Parametros)
 
    for t = 1:Parametros_ROW 
      REQM(t,1) = Parametros(t,1);
      RBits(t,1) = Parametros(t,2);
      THETAMIN(t,1) = Parametros(t,3);
      RBA(t,1) = Parametros(t,4);
      RBPh(t,1) = Parametros(t,5);  
    end
    
    for p = 2:Parametros_ROW 
      REQM_T(p-1,1) = Parametros(p,1);
      RBits_T(p-1,1) = Parametros(p,2);
      THETAMIN_T(p-1,1) = Parametros(p,3);
      RBA_T(p-1,1) = Parametros(p,4);
      RBPh_T(p-1,1) = Parametros(p,5);          
    end
    
%     THETAMIN   
%     THETAMIN_DEG = radtodeg(THETAMIN)
%     
%     THETAMIN_T
%     THETAMIN_T_DEG = radtodeg(THETAMIN_T)
%   
   Delt_Theta(:,1) = abs(THETAMIN_T(:,1) - Theta_Inicial_Rad)
    
%   figure
%   subplot(2,1,1);
%   plot(THETAMIN)
%   subplot(2,1,2);
%   scatter(RBits,REQM)



     [m,i] = min(Delt_Theta)

     THETA_CHOOSE_Rad = THETAMIN_T(i,1);
     THETA_CHOOSE_Deg = degtorad(THETA_CHOOSE_Rad);
     RBA_CHOOSE = RBA_T(i,1);
     RBPh_CHOOSE = RBPh_T(i,1);
     
CHOOSE(k,:) = [THETA_CHOOSE_Rad THETA_CHOOSE_Deg RBA_CHOOSE RBPh_CHOOSE]; 
    
end

CHOOSE
save 'CHOOSE.mat' CHOOSE;
