
clc
clear all
close all

load('Nuvem.mat')
[Dados_Bitsrow, Dados_Bitscol] = size(Dados_Bits)
pause


%DADOS_QUANTIZACAO(v,:) = [EQM NumberofBits v NBA NBPh NITER];


%Parametros_Bits = Dados_Bits
for w = 1:Dados_Bitsrow
    
    Dados_Por_Bloco = Dados_Bits{w,1}
    [Dados_Por_Blocorow, Dados_Por_Blococol] = size(Dados_Por_Bloco)
    pause
    


for e = 1:Dados_Por_Blocorow-1
    disp(['Bloco: ' num2str(e)]); 
    
    %LivrodeDados = Dados_Por_Bloco{1,e};
    LivrodeDados = Dados_Por_Bloco

    
%******ANTIGO*********
    MatRD(:,3) = LivrodeDados(:,1)        % Numero de Bits Utilizado na Ampitude
    MatRD(:,4) = LivrodeDados(:,2)        % Numero de Bits Utilizado na Fase
    MatRD(:,2) = LivrodeDados(:,3)        % MSE respectivo ao Numero Total de Bits Utilizado
    MatRD(:,1) = LivrodeDados(:,4)        % Numero Total de Bits Utilizado

    
%***************************************************************************
   
%     MatRD_NORM = MatRD(:,2)/max(MatRD(:,2));
%     
%     MatRD(:,2) = MatRD_NORM;
    
    
%***************************************************************************

    
    
    
    RBMin = min(MatRD(:,1))                % Numero de Bits Minimo
    RBMax = max(MatRD(:,1))                % Numero de Bits Maximo
    Ind_R0_Min = find (MatRD(:,1)==RBMin)  %Indice de onde ocorre o Numero de Bits Minimo 
    RMSEMin = MatRD(Ind_R0_Min,2)          % MSE respectivo ao Numero de Bits Minimo
    
    RB0 = RBMin
    RMSE0 = RMSEMin
    THETA0 = 0
       
    CurvaOP = [RB0 RMSE0 THETA0 0 0];                  %Pontos Selecionados
    
    MatRD_SEL = MatRD;
    
    while RB0 <= RBMax
    
          [NUMERODELINHAS,NUMERODECOLUNAS] = size(MatRD_SEL);
         
          Last_CurvaOP = CurvaOP(end,:);

    
          for k = 1:NUMERODELINHAS-1        
              Theta(k,1) = atan((MatRD_SEL(k,2)-Last_CurvaOP(2)) / (MatRD_SEL(k,1)-Last_CurvaOP(1)));  %Encontrando os Todos os Tetas    
          end
          
%           Theta
%           pause
             
         %Seleciono os Thetas menores que zero
         m=1;

         
         for p = 1:NUMERODELINHAS-1
             if Theta(p,1) < 0;
                 ThetaMenor(m,1) = Theta(p,1);
                 ThetaMenor(m,2) = p;
                 ThetaMenor(m,3) = MatRD_SEL(p,1);
                 ThetaMenor(m,4) = MatRD_SEL(p,2);
                 ThetaMenor(m,5) = MatRD_SEL(p,3);  % Numero de Bits Utilizado na Ampitude
                 ThetaMenor(m,6) = MatRD_SEL(p,4);   % Numero de Bits Utilizado na Fase
                 m = m+1;
             end

         end
        

         Theta;
         [ThetaROW,ThetaCOL] = size(Theta);
         
         
        ThetaMenor;
        
         [ThetaMenorROW,ThetaMenorCOL] = size(ThetaMenor);
   
         
         
         if ThetaMenorROW ==0;
             break
         end
         

         ThetaMin = min(ThetaMenor(:,1));               % Teta minimo
                 
         if ThetaMin < 0;           
             Ind_Ponto_op = find(Theta==ThetaMin);  %Indice de onde ocorre o Teta minimo 
             RBk =  MatRD_SEL(Ind_Ponto_op,1);      % Numero de Bits de onde ocorre o Teta minimo
             RMSEk = MatRD_SEL(Ind_Ponto_op,2);     % MSE de onde ocorre o Teta minimo
             RBAk =  MatRD_SEL(Ind_Ponto_op,3);     % Numero de Bits da Amplitude de onde ocorre o Teta minimo
             RPhk = MatRD_SEL(Ind_Ponto_op,4);      % Numero de Bits da Fase de onde ocorre o Teta minimo
         end
         
   
         
         MatRD_SEL = [];
         
         t=1;
         for s = 1:ThetaMenorROW
             if RBk < ThetaMenor(s,3);
                 MatRD_SEL(t,1) = ThetaMenor(s,3);
                 MatRD_SEL(t,2) = ThetaMenor(s,4);
                 MatRD_SEL(t,3) = ThetaMenor(s,5);   % Numero de Bits Utilizado na Ampitude
                 MatRD_SEL(t,4) = ThetaMenor(s,6);   % Numero de Bits Utilizado na Fase
                 t = t+1;
             end
         end
         
         MatRD_SEL;
         [NUMERODELINHAS,NUMERODECOLUNAS] = size(MatRD_SEL);

         ThetaMenor = [];
         
         %CurvaOP = [CurvaOP;RBk RMSEk];         %Pontos Selecionados atualizado   
         CurvaOP = [CurvaOP;RBk RMSEk ThetaMin RBAk RPhk];         %Pontos Selecionados atualizado 
         CurvaOP;
   
 
%          pause
         
    end
    
    figure(e)
    scatter(MatRD(:,1),MatRD(:,2));
    hold on
    scatter(CurvaOP(:,1),CurvaOP(:,2));
    plot(CurvaOP(:,1),CurvaOP(:,2));
    hold off
    
    
    THETA_BITS{1,e} = CurvaOP;
       
end
end

save 'THETA_BITS.mat' THETA_BITS;

disp('Fim');



