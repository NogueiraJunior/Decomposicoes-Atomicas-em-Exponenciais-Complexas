function [Aprox_Reconst_Quantizer] = Signal_Recons_Quantizer(AkrDic, PhikrDic, XirDic, N, IndMax, M, W0)


 %for k =0:IndMax-1;
 for k =0:N-1;
        %Aprox_Reconst_Quantizer(1,k+1) = ((2*AkrDic/W0)*cos(2*pi*XirDic*k+PhikrDic));
        Aprox_Reconst_Quantizer(1,k+1) = ((AkrDic)*cos(2*pi*XirDic*k+PhikrDic));
 end 
   
end