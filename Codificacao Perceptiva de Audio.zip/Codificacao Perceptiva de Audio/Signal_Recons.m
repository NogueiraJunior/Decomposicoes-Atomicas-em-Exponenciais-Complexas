function [Aprox_Reconst] = Signal_Recons(Akr, Phikr, Xir, N, IndMax, M, W0)




 for k =0:N-1;
           %Aprox_Reconst(1,k+1) = ((2*Akr/W0)*cos(2*pi*Xir*k+Phikr)); 
           Aprox_Reconst(1,k+1) = (Akr*cos(2*pi*Xir*k+Phikr)); 
         
 end



end