for i = 1 : length(CB)-1,
    i;
   % For each critical band, compute the power
   % in non-tonal components
   power  = MIN_POWER; % Partial sum
   weight = 0; % Used to compute the geometric mean of the critical band
      
     for p  = 1:N/2;
         
         if (CB(1,i)<TH(1,p) & CB(1,i+1)>=TH(1,p));
               if (Flags(TH(2,p)) == NOT_EXAMINED),    
                  power    = 10*log10(10^(power/10)+10^(X(TH(2,p))/10));
                  weight   = weight+10^(X(TH(2,p))/10)*(((13*atan(0.00076*TH(1,p)))+(3.5*atan((TH(1,p)/7500)^2)))-i);
                  Flags(TH(2,p)) = IRRELEVANT;
               end
         end
     end

 end
   
   % The index number for the non tonal component is the index nearest
   % to the geometric of the critical band
   
   if (power <= MIN_POWER)
       index = round(mean(CB(i) + CB(i+1)));
   else
      index = CB(i) + round(weight/10^(power/10)*(CB(i + 1) - CB(i)));
   end
   if (index < 1)
      index = 1;
   end
   if (index > length(Flags))
      index = length(Flags);
   end
   if (Flags(index) == TONAL)
      index = index + 1; % Two tonal components cannot be consecutive
   end
   
   % For each subband
   %   - index of the non-tonal component
   %   - sound pressure level of this component
   Non_tonal_list(i, INDEX) = index;
   Non_tonal_list(i, SPL) = power;
   Flags(index) = NON_TONAL;


if (DRAW),
   disp('Tonal and non-tonal components');
   plot(t, X(t), Tonal_list(:, INDEX), Tonal_list(:, SPL), 'ro', ...
     Non_tonal_list(:, INDEX), Non_tonal_list(:, SPL), 'go');
   xlabel('Frequency index'); ylabel('dB'); 
   title('Tonal and non-tonal components'); 
   axis([0 (N2) 0 100]); %pause;
end
end

