%Perceptually Weighted Limited Matching Pursuit

clc;
clear all;
close all;
disp('inicio')



[z,Fs] = audioread('pianoA3.wav');  

[N,M,s,MRT,BA,BPh,N_hop,Niter,dB,z_meio,z_quarto,z_Inicio] = Initial(z,Fs);

Initial_Parm = [N M N_hop dB MRT BA BPh s ];
  
save 'Initial_Parm.mat' Initial_Parm;
disp('Le o sinal de audio em WAV')

 [row_z ,col_z] = size(z);
 z_Fim = flip(z((row_z-(z_quarto)):row_z));
 zNew = [zeros(N_hop,1) ; z ; zeros(N_hop,1)];
 [row_zNew ,col_zNew] = size(zNew); 
 numBlock_nonoverlap = ceil(length(z)/N);
 zBase = [ zeros(z_quarto,1); zeros(z_meio-1,1); z_Inicio ; z ; z_Fim ; zeros(z_meio,1); zeros(z_quarto,1); zeros(numBlock_nonoverlap*N-length(z),1)];
 
 save 'zBase.mat' zBase;
 [row_zBase ,col_zBase] = size(zBase);
 Number_Of_Block = (length(zBase)/N_hop)-1;

 z =zBase;
 x =  z';
 sound(z,Fs);


 
disp('parametros discretos')
dicGammaSinusoidal = getDicParmDiscrete('sinusoidal_FFT',N,M);  % Calcula S, U e xi em fun��o dos par�metros discretos:
[row_Sinusoidal ,col_Sinusoidal] = size(dicGammaSinusoidal); 
numGammaSinusoidal = row_Sinusoidal;




Numer_Blocos_Itera = zeros(Number_Of_Block,1);

       for p = 1:M;
         ESCALA(1,p) = (p-1)*(Fs/M);                                                                %Frequencia [Hz] de cada passo Fs/N
      end


for kBlock = 1:Number_Of_Block;
    disp(['Bloco: ' num2str(kBlock)]); 
    

    a = N_hop*(kBlock-1)+1;
    b = a+N-1;
    

    residue = x(a:b);
      
    
    [rowresidue,colresidue]=size(residue);
    Length_Of_Block = length(residue);
    
      %******************************************************************

%       disp('Janela de Hanning');

      w = hanning(N);
      x_Hanning(a:b) = w'.*x(a:b);    
      
      %******FFT POR w, MATRIZ COLUNA DE ELEMENTOS DIAGONAIS*************      
      %disp('FFT POR w MATRIZ COLUNA DE ELEMENTOS DIAGONAIS');
      
       W_FFT = fft(w,M)/(N);
       
       W0 = W_FFT(1,1);
      
    
      %******************************************************************

      ChosenParm = zeros(Number_Of_Block,4); 
      [rowChosenParm,colChosenParm]=size(ChosenParm);
      

      Number_Of_Iter = zeros(Number_Of_Block,1);

      Prod_Point_Point = w.*(residue');  %produto interno matricial            
      Rw = fft(Prod_Point_Point,M)/(N);

      [LTtM, LTnM, THNM, XM, TqNM, LTgM, SMR] = Psychoacoustics_M (Rw,Fs,s,kBlock,ESCALA);
     

       
       LTg_REBM = [LTgM fliplr(LTgM)];
       LTg_MNORM = LTg_REBM/max(LTg_REBM);
       LTg_MCOMPLEMENTAR = (1.1 - LTg_MNORM);

      GammaPsychoMask = ones(1,M);      
      [GammaPsychoMaskrow,GammaPsychoMaskcol] = size(GammaPsychoMask);

     
      Aprox = zeros(1,N);
      
            RwLOG = 20*log10(abs(Rw));
            RwLOGMAX = max(RwLOG);
            Delta = 96-RwLOGMAX;
            RwLOG = Delta + RwLOG;
            



      
      for iter = 1:Niter
          if norm(Prod_Point_Point)==0 
              break;
          end
       
              
          [FLAG_RW,Rw_dB] = Flag_Rw(Rw,M,Delta,LTgM,dB);
                          
          
                 if sum(FLAG_RW) == 0;
                     
                    Number_Of_Iter(iter,:) = (iter - 1); 
                    
                    Iteracao = (iter - 1);

                    
                      figure(kBlock)
                
                      semilogx(ESCALA(1:M/2),LTgM, 'k-','LineWidth',2);
                      hold on
                      grid on
                      semilogx(ESCALA(1:M/2),Rw_dB(1:M/2), 'b-.','LineWidth',2);
                      semilogx(ESCALA(1:M/2),XM(1:M/2), 'r--')
                      legend('Limar Global','Residuo','Dens. Espectral do Sinal');
                      title(['Lim. Global VS Residuo VS Dens. Espectral do Sinal ' num2str(kBlock) ' com ' num2str(iter -1) ' iteracoes com ' num2str(dB) ' dB'])
                      xlabel('Frequ�ncia (Hz)');
                      ylabel('N�veld e Press�o (dB)');
                      hold off
                      axis([0 50000 -50 250])
                      drawnow
                      

                  
                     break;
                     
                 else
                     
                     if iter == Niter;
                         
                    figure(kBlock)
                
                      semilogx(ESCALA(1:M/2),LTgM, 'k-','LineWidth',2);
                      hold on
                      grid on
                      semilogx(ESCALA(1:M/2),Rw_dB(1:M/2), 'b-.','LineWidth',2);
                      semilogx(ESCALA(1:M/2),XM(1:M/2), 'r--')
                      legend('Limar Global','Residuo','Dens. Espectral do Sinal');
                      title(['Lim. Global VS Residuo VS Dens. Espectral do Sinal ' num2str(kBlock) ' com ' num2str(iter -1) ' iteracoes com ' num2str(dB) ' dB'])
                      xlabel('Frequ�ncia (Hz)');
                      ylabel('N�veld e Press�o (dB)');
                      hold off
                      axis([0 50000 -50 250])
                      drawnow
 
                     end
                     Iteracao = (iter - 1);
                     

                     
                 end
                 
          Numer_Blocos_Itera(kBlock,:) = Iteracao ;  

          %******ELEMENTO MAXIMO DO PRODUTO INTERNO POR 'max', RETORNA O MAXIMO DE MODULO E FASE****************
          
          RwGamma = (Rw./(GammaPsychoMask'));

          Abs_Rw = (abs(RwGamma(1:M/2))).*FLAG_RW;
          
          Rw_Value_Max = max(Abs_Rw);                          
                                                                                                                            
          IndMax = find(abs(RwGamma(1:M/2))==Rw_Value_Max);    
          IndMax=IndMax(1);                                    
          

          Rw_Max = Rw(IndMax);                                 
                    
          
          ak = (abs(Rw_Max)); 
          Ak = (2*ak)/W0;
          Phik = angle(Rw_Max);
          Xi = dicGammaSinusoidal(IndMax,3);

          ChosenParm(iter,:) = [Ak Phik Xi IndMax]; 
                    
          AproxParm = 0;
          

          %****************************************************************** 
          %******************************************************************              
          
          W1 = circshift(W_FFT,(IndMax-1));   
          W2 = circshift(W_FFT,(-IndMax+1));  

           Aprox = ((Ak/2)*(((exp(i*Phik))*W1)+((exp(-i*(Phik)))*W2)));

          [Aproxrow, Aproxcol] = size(Aprox);

          Rw = Rw - Aprox;

          W1 = 0;
          W2 = 0;

        
      end

      
      Residue_Final{1,kBlock} = Rw_dB;
      Dens_Sinal_Orig{1,kBlock} = XM;
      Limiar_Sinal_Origi{1,kBlock} = LTgM;
      
      Rw = 0;
      Rw_1 = 0;
      Aprox = 0;
      LTtM = 0;
      LTnM = 0;
      THNM = 0;
      XM = 0;
      TqNM = 0;
           
      result_decomp{1,kBlock} = ChosenParm;

       
      %pause
          
end  




figure(kBlock+1)
stairs(Numer_Blocos_Itera,'k')
title('Numero de iteracoes por Bloco');
ylabel('Iteracao')
xlabel('Bloco')
grid on
saveas(gcf, 'Numero_de_iteracoes_por_Bloco')


Nome_Do_Arquivo_2 = ['IterPorBloco' num2str(dB) 'dBHan512pianoA3' ];
saveas(gcf, Nome_Do_Arquivo_2,'jpg')
saveas(gcf, Nome_Do_Arquivo_2)

save 'IterPorBloco.mat' Numer_Blocos_Itera;

save 'Residue_Final.mat' Residue_Final;
save 'Dens_Sinal_Orig.mat' Dens_Sinal_Orig;
save 'Limiar_Sinal_Origi.mat' Limiar_Sinal_Origi;


save 'result_decomp.mat' result_decomp;

close all

disp('Final da decomposicao');



