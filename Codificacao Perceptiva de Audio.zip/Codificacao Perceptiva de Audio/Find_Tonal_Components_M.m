function [Flags, Tonal_list, Non_tonal_list] = Find_Tonal_Components_M(X,CB,Local,s,M,Fs) 
Common;

SOMATOTAL = 0;

%disp('Find_tonal_components_TESTE_VALMIR')

% Check input parameters

%if (length(X) ~= FFT_SIZE)
   %error('Unexpected power density spectrum size.');
%end

N = length(X);


% List of flags for all the frequency lines (1 to FFT_SIZE / 2)
Flags = zeros(N/2,1) + NOT_EXAMINED;

% Label the local maxima
local_max_list = [];
counter = 1;
for k = 2 : N/2-1, % Don't care avout the borders
   if (X(k) > X(k-1) & X(k) >= X(k+1) & k > 2 & k <= ((N/2)-2))
      local_max_list(counter, INDEX) = k;    %Indice do local max  "2 ate N/2-1"
      local_max_list(counter, SPL) = X(k);   %Valor da densidade do local
      local_max_list(counter, 3) = k*(Fs/M); %Indice do local max  "em frequencia"
      counter = counter + 1;
   end
end

local_max_list;


% List tonal components and compute sound pressure level
%disp('List tonal components and compute sound pressure level')

Tonal_list = [];
counter = 1;
if not(isempty(local_max_list))
	for i = 1:length(local_max_list(:, 1)),
	   k = local_max_list(i, INDEX);
	   is_tonal = 1;
	   
	   % Layer I
	   % Examine neighbouring frequencies
	   if (2 < k & k < (63*6))                   
	      J = [-2 2];
	   elseif ((63*6) <= k & k < (127*6))        
	      J = [-3 -2 2 3];
	   elseif ((127*6) <= k & k < (255*6))       
	      J = [-6:-2, 2:6];
       elseif ((255*6) <= k & k < (510*6))       
	      J = [-12:-2, 2:12];
	   else
	      is_tonal = 0;
	   end
	   
	   for j = J,
	      is_tonal = is_tonal & (X(k) - X(k+j) >= 7);
	   end
	   
	   % If X(k) is actually a tonal component then the following are listed
	   %    - index number k of the spectral line
	   %    - sound pressure level
	   %    - set tonal flag
	   if is_tonal
	      Tonal_list(counter, INDEX) = k;
	      Tonal_list(counter, SPL) = 10*log10 (10^(X(k-1)/10) + 10^(X(k)/10) + 10^(X(k+1)/10)); 
          Tonal_list(counter, 3) = k*(Fs/M); %Indice do local max  "em frequencia"
	      Flags(k) = TONAL;
	      for j = [J -1 1],
	         Flags(k + j) = IRRELEVANT;
	      end
	      counter = counter + 1;
       end
             
    end
      
 
end



% List the non tonal components and compute power
% All the spectral lines that have not been examined during the previous
% search are summed together to form the non-tonal component.
Non_tonal_list = [];
counter = 1;

%disp('List non tonal components and compute sound pressure level')
    
 Espectro_BC(1,length(CB)) = zeros; 
  
 for i = 1:length(CB)-1,
    for p = 1:N/2;
         if Local(1,p)==i;
             if Espectro_BC(1,i)<=p;
                   Espectro_BC(1,i)=p;
             end
         end
    end
 end
 
 Local;
 Espectro_BC;
 %pause
 
  for i = 1:length(CB)-1, %i varia de 1 at� 25, o numero de bandas criticas
   % For each critical band, compute the power
   % in non-tonal components
   power  = MIN_POWER; % Partial sum
   weight = 0; % Used to compute the geometric mean of the critical band
%**************************************************************************
%**************************************************************************  
%*********TESTE*********TESTE*********TESTE*********TESTE*********TESTE****
%**************************************************************************
%**************************************************************************   
   
   power_basic = 10^(power / 10);
   power_spectrum = 0;
   Number_Non_Tonais = 0;

    for p = 1:N/2;
        if Local(1,p)==i
            if (Flags(p) == NOT_EXAMINED),
                power_spectrum  = power_spectrum + 10^(X(p)/10) ;
                Number_Non_Tonais = Number_Non_Tonais + 1;
                weight   = weight + p;
                Flags(p) = IRRELEVANT;
            end
            power   = 10 * log10(power_basic + power_spectrum);
        end
    end
 
    % The index number for the non tonal component is the index nearest
    % to the geometric of the critical band        
            
    %disp('The index number for the non tonal component');   
      if (power <= MIN_POWER);
         index = round(mean(Espectro_BC(1,i)+Espectro_BC(1,i+1)));
      else
         index =  ceil(weight/Number_Non_Tonais) ;
     end

     if (index < 1);
        index = 1;
     end
     
     if (index > length(Flags));
         index = length(Flags);
     end

     if (Flags(index) == TONAL);
         index = index + 1;  % Two tonal components cannot be consecutive
     end
    
     % For each subband
     %   - index of the non-tonal component
     %   - sound pressure level of this component
 
     Non_tonal_list(i, INDEX) = index;
     Non_tonal_list(i, SPL) = power;
     Non_tonal_list(i, 3) = index*(Fs/M); %Indice do local max  "em frequencia"
     
     
     Flags(index) = NON_TONAL;   
   
   
   
%**************************************************************************
%**************************************************************************
%**************************************************************************   
%    for p = 1:N/2;
%        if Local(1,p)==i
%            if (Flags(p) == NOT_EXAMINED),
%                power    = 10 * log10(10^(power / 10) + 10^(X(p) / 10));
%                weight   = weight + 10^(X(p) / 10) * (THN(2,p) - i);
%                Flags(p) = IRRELEVANT;
%                Comparar(1,p)=power;
%                Comparar(2,p)=weight;
%            end
%        end
%    end
% 
%    % The index number for the non tonal component is the index nearest
%    % to the geometric of the critical band        
%            
%    %disp('The index number for the non tonal component');   
%      if (power <= MIN_POWER);
%          
%         %disp(' if (power <= MIN_POWER)')
%         index = round(mean(Espectro_BC(1,i)+Espectro_BC(1,i+1)));
%  
%     else
%     %if (power <= MIN_POWER)
%         %disp(' if (power <= MIN_POWER)')
%          %or p = 1:N/2;
%              %if Local(1,p)==i
%                %SOMATOTAL = SOMATOTAL + p
%              %end
%          %end
%                %index = round(mean(SOMATOTAL))
%     %else
%                %i
%                %p  
%                %disp(' index = p + round(weight / 10^(power / 10) *(CB(1,i)))')
%                index = Espectro_BC(1,i) + round(weight / 10^(power / 10) *abs(Espectro_BC(1,i+1)-Espectro_BC(1,i)));
%     end
%     %disp(' if (index < 1)')
%     if (index < 1);
%        index = 1;
%     end
%      %disp('if (index > length(Flags))')
%     if (index > length(Flags));
%        index = length(Flags);
%     end
%     %disp('if (Flags(index) == TONAL)')
%     if (Flags(index) == TONAL);
%        index = index + 1; % Two tonal components cannot be consecutive
%     end
%    
%     % For each subband
%     %   - index of the non-tonal component
%     %   - sound pressure level of this component
% 
%     Non_tonal_list(i, INDEX) = index;
%     Non_tonal_list(i, SPL) = power;
%     
%     Flags(index) = NON_TONAL;
  end
%Comparar'
 %disp('Fim Volta')
          
  
 
   

   
   