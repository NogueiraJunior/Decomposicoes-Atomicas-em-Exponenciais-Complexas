function [N,M,N_hop,dB,MRT,BA,NBA,BPh,NBPh,s] = Lendo_Parm(Initial_Parm)


N = Initial_Parm(1,1)
M = Initial_Parm(1,2);
N_hop = Initial_Parm(1,3)
dB = Initial_Parm(1,4);
MRT = Initial_Parm(1,5);
BA = Initial_Parm(1,6);
NBA = BA;
BPh = Initial_Parm(1,7);
NBPh = BPh;

s = Initial_Parm(1,8);