function [EQM,NumberofBits] = MSE_NumberofBits(X,Xapp,BA,BPh,M,NITER)
% Esta funcao retorna o valores de ERRO MEDIO(EM), ERRO MEDIO ABSOLUTO
% (EMA), ERRO QUADRATICO MEDIO (EQM) e o numero total de bits utilizado.
%ERRO MEDIO(EM)
%EM = (Somatorio(At - Aproxt))/ n; n = Numero de periodos utilizado
%EMA = (Somatorio(Abs(At - Aproxt)))/ n; n = Numero de periodos utilizado
%EQM = (Somatorio((At - Aproxt))^2)/ n; n = Numero de periodos utilizado

et = X-Xapp;
absD = abs(et);

A = et.^2;
%A    = absD.^2;

%MSE  = sum(A(:))/numel(X);
% MSE  = ((sum(A(:)))^(1/2))/numel(X);

% %ERRO MEDIO(EM)
% SumD = sum(D);
% EM = SumD/Xcol;
% 
% %ERRO MEDIO ABSOLUTO (EMA)
% SumabsD = sum(absD);
% EMA = SumabsD/Xcol;

%ERRO QUADRATICO MEDIO (EQM)
 EQM = (sum(A(:)))/numel(X);


Number_Bits  = (BA + BPh + (log2(M/2)));
NumberofBits = NITER*Number_Bits;
%pause

