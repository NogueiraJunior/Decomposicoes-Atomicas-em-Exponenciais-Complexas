function [X, Delta]  = FFT_Analysis_M(Input)
%X = FFT_Analysis(Input, n)

%-------------------------------------------------------------------------------
Common;

%disp('FFT_Analysis_TESTE')

Delta = [];
X = [];


% Power density spectrum 

X =20*log10(abs(Input));
  
Xmax = max(X);

% Normalization to the reference sound pressure level of 96 dB
Delta = 96-Xmax;


X =Delta + X;
