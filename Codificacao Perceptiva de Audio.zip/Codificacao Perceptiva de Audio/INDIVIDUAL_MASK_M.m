 
function  [LTt, LTn] = INDIVIDUAL_MASK_M(X, Tonal_list,Non_tonal_list,THN)

Common;

%disp('INDIVIDUAL_MASK_M')


% Individual masking thresholds for both tonal and non-tonal 
% components are set to -infinity since the masking function has
% infinite attenuation beyond -3 and +8 barks, that is the component
% has no masking effect on frequencies beyond thos ranges [1, pp. 113--114]

if isempty(Tonal_list)
   LTt = [];
else
   LTt = zeros(length(Tonal_list(:, 1)), length(X)/2) + MIN_POWER;
end
   LTn = zeros(length(Non_tonal_list(:, 1)), length(X)/2) + MIN_POWER;




% Only a subset of the samples are considered for the calculation of
% the global masking threshold. The number of these samples depends
% on the sampling rate and the encoding layer. All the information
% needed is in TH which contains the frequencies, critical band rates
% and absolute threshold.
for i = 1:length(X)/2
        zi = THN(2,i);  % Critical band rate of the frequency considered   
   
   if not(isempty(Tonal_list))
	   % For each tonal component
	   for k = 1:length(Tonal_list(:, 1)),
	           j  = Tonal_list(k, INDEX);
	           zj = THN(2, j);           % Critical band rate of the masker
	           dz = zi - zj;             % Distance in Bark to the masker
	      
	      if (dz >= -3 & dz < 8)
	         
	         % Masking index
	         avtm = -1.525 - 0.275 * zj - 4.5;
	         
	         % Masking function
	         if (-3 <= dz & dz < -1)
	            vf = 17 * (dz + 1) - (0.4 * X(j) + 6);
	         elseif (-1 <= dz & dz < 0)
	            vf = (0.4 * X(j) + 6) * dz;
	         elseif (0 <= dz & dz < 1)
	            vf = -17 * dz;
	         elseif (1 <= dz & dz < 8)
	            vf = - (dz - 1) * (17 - 0.15 * X(j)) - 17;
	         end
         
	         LTt(k, i) = X(j) + avtm + vf;
	      end
      end
   end
   
   
   % For each non-tonal component
   for k = 1:length(Non_tonal_list(:, 1)),
        j  = Non_tonal_list(k, INDEX);
        zj = THN(2, j);        % Critical band rate of the masker
        dz = zi - zj;          % Distance in Bark to the masker
      
        if (dz >= -3 & dz < 8)
         
           % Masking index
           avnm = -1.525 - 0.175 * zj - 0.5;
         
           % Masking function
         if (-3 <= dz & dz < -1)
             vf = 17 * (dz + 1) - (0.4 * X(j) + 6);
         elseif (-1 <= dz & dz < 0)
             vf = (0.4 * X(j) + 6) * dz;
         elseif (0 <= dz & dz < 1)
             vf = -17 * dz;
         elseif (1 <= dz & dz < 8)
             vf = - (dz - 1) * (17 - 0.15 * X(j)) - 17;
         end
         
         LTn(k, i) = X(j) + avnm + vf;
      end
   end
end
