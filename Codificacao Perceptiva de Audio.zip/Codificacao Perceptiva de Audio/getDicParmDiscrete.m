function dicParm = getDicParmDiscrete(options,N,M)

 
  % Inicio Sinusoidal;
 
 if strcmp(options,'sinusoidal_FFT')
        
     dicParm = zeros(M,3);
     
      %s = N;
      s = 1/N;
      u = 0;
       
     
    for m=0:M-1
         %xi= 2*pi*(m/M); 
         xi= (m/M);
         dicParm(m+1,:) = [s u xi];
    end
 end
 

end