function [THN, CB, Local,TqN] = Table_absolute_threshold_M(M, Fs, bitrate)

THN = 0;
Local = 0;
TqN = 0;


     for p = 1:M/2;
         THN(1,p) = (p-1)*(Fs/M);                                                                %Frequencia [Hz] de cada passo Fs/N
         THN(2,p) = (13*atan(0.00076*THN(1,p))) + (3.5*atan(((THN(1,p))/7500)^2));               %Dependencia da escala Bark com a Frequencia [Hz] de cada passo Fs/n, em Bark 
     end 
        
        CB = [1,102, 204, 309, 417, 531, 652, 781, 923, 1079, 1255, 1457, 1691, 1969, 2303, 2711, 3212, 3823, 4554, 5412, 6414, 7618, 9167,11416, 15429, 26646];
     
        
      TqN(1,1) = 0;  
     for k = 2:M/2                                                                                               
         TqN(1,k) = 3.64*((THN(1,k)/1000)^(-8/10))-6.5*exp((-6/10)*(((THN(1,k)/1000)-3.3)^2))+(10^(-3))*(((THN(1,k)/1000)^4)); % Limite do Silencio [dB SPL]         
          if bitrate > 96;            
              TqN(1,k) = TqN(1,k) - 12;              
          end
     end 
        TqN(1,1) = max(TqN); 
        
        
        for i = 1 : length(CB)-1,
            for p  = 1:M/2;
                if (CB(1,i)<THN(1,p) & CB(1,i+1)>=THN(1,p));
                     Local(1,p) = i;                                                      % Frequencia [Hz] de capa passo Fs/N que esta em cada Banda Critica
                end  
            end 
        end
        
end