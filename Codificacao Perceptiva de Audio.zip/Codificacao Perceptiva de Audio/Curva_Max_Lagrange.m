clc
clear all
close all

load('Nuvem.mat')
TOTAL_DADOS;
[row_TOTAL_DADOS ,col_TOTAL_DADOS] = size(TOTAL_DADOS)




%[z,Fs] = audioread('pianoA3.wav');          %Retorna a taxa de amostragem (Fs) em Hertz usada para codificar os dados do arquivo
%[z,Fs] = audioread('cello_A4.wav');          %Retorna a taxa de amostragem (Fs) em Hertz usada para codificar os dados do arquivo
%[z,Fs] = audioread('fagotto_A_4.wav');      %Retorna a taxa de amostragem (Fs) em Hertz usada para codificar os dados do arquivo
%[z,Fs] = audioread('flute_A4.wav');        %Retorna a taxa de amostragem (Fs) em Hertz usada para codificar os dados do arquivo
%[z,Fs] = audioread('drumsA.wav');        %Retorna a taxa de amostragem (Fs) em Hertz usada para codificar os dados do arquivo
%z = 0.9*z;
%[z,Fs] = audioread('drumsB.wav');        %Retorna a taxa de amostragem (Fs) em Hertz usada para codificar os dados do arquivo
[z,Fs] = audioread('tiro.wav');        %Retorna a taxa de amostragem (Fs) em Hertz usada para codificar os dados do arquivo
z = 0.9*z;

N = 512;
N_hop = N/2;
Number_Of_Block =  floor(length(z)/N_hop); %Numero de blocos arredondado para baixo, sem os complementos de zeros

EQM_TOTAL = [];
NB_TOTAL = [];

for f = 1:Number_Of_Block
    
    disp(['Cojnuto de Bits: ' num2str(f)]);
    
DADOS_QUANTIZACAO_TOTAL = TOTAL_DADOS{f,1};

[row_DADOS_QUANTIZACAO_TOTAL,col_DADOS_QUANTIZACAO_TOTAL] = size(DADOS_QUANTIZACAO_TOTAL);


DADOS_QUANTIZACAO = DADOS_QUANTIZACAO_TOTAL;

EQM_TOTAL = [EQM_TOTAL; DADOS_QUANTIZACAO(:,1)];
NB_TOTAL = [NB_TOTAL; DADOS_QUANTIZACAO(:,2)];
end

[row_EQM_TOTAL ,col_EQM_TOTAL] = size(EQM_TOTAL)

figure(1)
plot(EQM_TOTAL)


[row_NB_TOTAL ,col_NB_TOTAL] = size(NB_TOTAL)

figure (2)
plot(NB_TOTAL)

% pause

EQM_MAX_TOTAL = max(EQM_TOTAL);
NB_MAX_TOTAL = max(NB_TOTAL);
All_Theta = [];

for e = 2:(row_TOTAL_DADOS-1)
%for e = 3:(Number_Of_Block-1)
    
    disp(['Cojnuto de Bits: ' num2str(e)]);
    
DADOS_QUANTIZACAO_TOTAL = TOTAL_DADOS{e,1};

[row_DADOS_QUANTIZACAO_TOTAL,col_DADOS_QUANTIZACAO_TOTAL] = size(DADOS_QUANTIZACAO_TOTAL);

% pause


DADOS_QUANTIZACAO = DADOS_QUANTIZACAO_TOTAL;

MatRD(:,1) = DADOS_QUANTIZACAO(:,1);        % EQM respectivo ao Numero Total de Bits Utilizado
% MatRD(:,1) = MatRD(:,1)/max(MatRD(:,1));
MatRD(:,1) = MatRD(:,1)/EQM_MAX_TOTAL;

MatRD(:,2) = DADOS_QUANTIZACAO(:,2);        % Numero Total de Bits Utilizado
% MatRD(:,2) = MatRD(:,2)/max(MatRD(:,2));
MatRD(:,2) = MatRD(:,2)/NB_MAX_TOTAL;

MatRD(:,3) = DADOS_QUANTIZACAO(:,3); 
MatRD(:,4) = DADOS_QUANTIZACAO(:,4);        % Numero de Bits Utilizado na Ampitude      
MatRD(:,5) = DADOS_QUANTIZACAO(:,5);        % Numero de Bits Utilizado na Fase
MatRD(:,6) = DADOS_QUANTIZACAO(:,6);        % Numero de Iteracoes


 [NBMin,INBMin] = min(MatRD(:,2));           % Valor e Indice de onde ocorre o Numero de Bits Minimo 
 [NBMax,INBMax] = max(MatRD(:,2));                   % Numero de Bits Maximo
 EQMMin = MatRD(INBMin,1);                   % EQM respectivo ao Numero de Bits Minimo
 
 NB0 = NBMin;
 EQM0 = EQMMin;
 THETA0 = 0;
       
 CurvaOP = [EQM0 NB0 THETA0 0 0];              %Pontos Selecionados

    
 MatRD_SEL = MatRD;
 
 ThetaMenor = [];
 
 
     while NB0 <= NBMax
    
          [NUMERODELINHAS,NUMERODECOLUNAS] = size(MatRD_SEL);
         
          Last_CurvaOP = CurvaOP(end,:);
Last_CurvaOP(1);
Last_CurvaOP(2);
          
          for k = 1:NUMERODELINHAS-1  
              EQM_ATUAL = MatRD_SEL(k,1);
              NBits_Atual = MatRD_SEL(k,2);
              Theta_Rad(k,1) = atan((EQM_ATUAL - Last_CurvaOP(1)) / (NBits_Atual-Last_CurvaOP(2)));  %Encontrando os Todos os Tetas em Radianos  
              Theta_Deg = radtodeg(Theta_Rad);
          end
          
%           Theta_Rad
%           Theta_Deg
%           
%           pause
          
         %Seleciono os Thetas menores que zero
         m=1;
        
         for p = 1:NUMERODELINHAS-1
             if Theta_Rad(p,1) < 0;
                 ThetaMenor(m,1) = Theta_Rad(p,1);
                 ThetaMenor(m,2) = p;
                 ThetaMenor(m,3) = MatRD_SEL(p,1);    % EQM respectivo ao Numero Total de Bits Utilizado
                 ThetaMenor(m,4) = MatRD_SEL(p,2);    % Numero Total de Bits Utilizado
                 ThetaMenor(m,5) = MatRD_SEL(p,4);    % Numero de Bits Utilizado na Ampitude
                 ThetaMenor(m,6) = MatRD_SEL(p,5);    % Numero de Bits Utilizado na Fase
                 m = m+1;
             end
         end
        

         Theta_Rad;
         [ThetaROW,ThetaCOL] = size(Theta_Rad);
         
         
        ThetaMenor;        
        [ThetaMenorROW,ThetaMenorCOL] = size(ThetaMenor);
   
         
         
         if ThetaMenorROW ==0;
             break
         end
         


         [ThetaMin,IThetaMin] = min(ThetaMenor(:,1));               % Teta minimo                 
         if ThetaMin < 0;           
             EQM_Prox =  ThetaMenor(IThetaMin,3);    % EQM de onde ocorre o Teta minimo
             NB_Prox = ThetaMenor(IThetaMin,4);      % Numero de Bits de onde ocorre o Teta minimo
             NBA_Prox =  ThetaMenor(IThetaMin,5);    % Numero de Bits da Amplitude de onde ocorre o Teta minimo
             NPh_Prox = ThetaMenor(IThetaMin,6);     % Numero de Bits da Fase de onde ocorre o Teta minimo
         end
         
         
         MatRD_SEL = [];
         
         t=1;
         for s = 1:ThetaMenorROW
             if NB_Prox < ThetaMenor(s,4);
                 MatRD_SEL(t,1) = ThetaMenor(s,3);   % EQM
                 MatRD_SEL(t,2) = ThetaMenor(s,4);   % N TOTAL BITS
                 MatRD_SEL(t,4) = ThetaMenor(s,5);   % Numero de Bits Utilizado na Ampitude
                 MatRD_SEL(t,5) = ThetaMenor(s,6);   % Numero de Bits Utilizado na Fase
                 t = t+1;
             end
         end
         
         MatRD_SEL;
         [NUMERODELINHAS,NUMERODECOLUNAS] = size(MatRD_SEL);

         ThetaMenor = [];
         
         %CurvaOP = [CurvaOP;RMSEk RBk ThetaMin];         %Pontos Selecionados atualizado   
         CurvaOP = [CurvaOP;EQM_Prox NB_Prox ThetaMin NBA_Prox NPh_Prox];         %Pontos Selecionados atualizado 
         All_Theta = [All_Theta; ThetaMin];
   
 
%           pause
         
     end
    

     
    figure
    scatter(MatRD(:,2),(MatRD(:,1)));
    title(['EQM X NTBits do Bloco' num2str(e) 'com Itera = ' num2str(DADOS_QUANTIZACAO(1,6)) ])
    hold on
    scatter(CurvaOP(:,2),(CurvaOP(:,1)));
    plot(CurvaOP(:,2),(CurvaOP(:,1)));
    hold off
    drawnow
    Nome_Do_Arquivo_2 = ['EQM X NTBits do Bloco = ' num2str(e) ];
%     saveas(gcf, Nome_Do_Arquivo_2,'jpg')
%     saveas(gcf, Nome_Do_Arquivo_2,'fig')
    
   THETA_BITS{1,e} = CurvaOP;
   
   
%    CurvaOP
%     pause
%     
end 

close all
 All_Theta;


save 'THETA_BITS.mat' THETA_BITS;
save 'All_Theta.mat'  All_Theta;
    
    
    disp('Final TESTE');