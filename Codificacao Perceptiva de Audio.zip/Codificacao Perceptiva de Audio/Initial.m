function [N,M,s,MRT,BA,BPh,N_hop,Niter,dB,z_meio,z_quarto,z_Inicio] = Initial(z,Fs);

N = 512;
M = 2048;
s = 4;

MRT = 1;


BA = 16;

BPh = 32;

N_hop = 256;
Niter = 6*N

 z_meio = N_hop/2
 z_quarto = N_hop/4
 z_Inicio = z(1:z_quarto);

dB = 0;