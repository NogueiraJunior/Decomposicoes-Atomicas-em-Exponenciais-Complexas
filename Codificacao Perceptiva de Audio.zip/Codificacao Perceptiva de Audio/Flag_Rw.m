function [FLAG_RW,Rw_dB] = Flag_Rw(Rw,M,Delta,LTgM,dB);


          Rw_dB = 20*log10(abs(Rw));
          Rw_dB =Delta + Rw_dB;
          
           FLAG_RW = ones(M/2,1);
            for i =1:M/2;
                if Rw_dB(i) < (LTgM(i)) - dB
                    FLAG_RW(i) = 0;
                end
            end
            
            %figure (9) 
            %plot([Rw_dB(1:M/2) LTgM(1:M/2)']);
            FLAG_RW;
end