function [Lbc,LTmin,SMR] = Level_Sound_BC(X,CB, Local, N, LTg)
Common;

Espectro_BC(1,length(CB)) = zeros;

  
 for i = 1:length(CB)-1,
    for p = 1:N/2;
         if Local(1,p)==i;
             if Espectro_BC(1,i)<=p;
                   Espectro_BC(1,i)=p;
             end
         end
    end
 end
 

 
  for i = 1:length(CB)-1, %i varia de 1 at� 25, o numero de bandas criticas
   % For each critical band, compute the power
   % in non-tonal components
   power  = MIN_POWER; % Partial sum
   weight = 0; % Used to compute the geometric mean of the critical band  
   
   power_basic = 10^(power / 10);
   power_spectrum = 0;

      for p = 1:N/2;
          if Local(1,p)==i
         
               power_spectrum  = power_spectrum + 10^(X(p)/10) ;           
               power(1,i)  = 10 * log10(power_basic + power_spectrum);
            
          end
          power_spectrum = 0;
      end
    
      
   FSC = [ 2; 1.25992105; 0.793700526; 0.5; 0.314980262;
       0.198425131; 0.125; 0.078745066; 0.049606283;
       0.03125; 0.019686266; 0.015097196; 0.010508125;
       0.007617192; 0.005796018; 0.00464875; 0.003926017;
       0.003470723; 0.003183906; 0.003003223; 0.0028894;
       0.002817695; 0.002772524; 0.002744069; 0.002726143;
       0.00271485; 0.002707736];
   
      
   %Lbc(1,i) = max(power(1,i),20*log(2*32.768)-10); %(dB)
   %Lbc(1,i) = max(power(1,i),20*log(FSC(i,1)*32.768)-10); %(dB)
   Lbc(1,i) = max(power(1,i)); %(dB)
      
  end
  
   
  LTG = ones(length(CB),N/2) * 1000000000;
  
  
for i = 1:length(CB)-1,          
  for r = 1:N/2;
          if Local(1,r)==i 
              LTG(i,r) = LTg(1,r);               
          end
  end
  
  
  LTG;
  
   LTmin(1,i) = min(LTG(i,:));
           
   SMR(1,i) = Lbc(1,i) - LTmin(1,i);
   

  
end



