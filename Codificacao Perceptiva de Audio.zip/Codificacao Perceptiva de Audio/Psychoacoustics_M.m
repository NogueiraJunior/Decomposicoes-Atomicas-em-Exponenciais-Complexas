
function [LTt, LTn, THN, X, TqN, LTgM, SMR] = Psychoacoustics_M (Rw,Fs,s,kBlock,ESCALA)

%disp('Psicoacustico com M passos, onde m = s*N');

     bitrate = 128;
     Signal_In = Rw';
     N = length(Signal_In); %Sinal janelado no dominio da frequencia = M    
     [rowSignal_In,colSignal_In]=size(Signal_In);

     %Defini��es dos parametros psicoacusticos
        Common;
      
     % Load tables.
      
     [THN, CB, Local,TqN] = Table_absolute_threshold_M(N, Fs, bitrate); % Threshold in quiet

               
      % Compute the FFT for time frequency conversion [1, pp. 110].       
           
      X = FFT_Analysis_M(Signal_In);
      [rowX,colX]=size(X);


     % Find the tonal (sine like) and non-tonal (noise like) components

      [Flags Tonal_list Non_tonal_list] = Find_Tonal_Components_M(X,CB,Local,s,N,Fs);
      
      
            
     
       % Decimate the maskers: eliminate all irrelevant maskers [1, pp. 114]

       [Flags Tonal_list Non_tonal_list] = DEC_M(X, Tonal_list, Non_tonal_list, Flags,TqN);
       

                     
        % Compute the individual masking thresholds [1, pp. 113--114]

           [LTt, LTn] = INDIVIDUAL_MASK_M(X, Tonal_list, Non_tonal_list,THN);
           
 
                      
        
     %Compute the Global masking thresholds [1, pp. 113--114]
     LTgM = Global_masking_threshold_VALMIR(TqN,LTt,LTn);
     


 %**************************************************************
       
       % Compute the Sound Pressure Level for Critical Band;
     
          [Lbc,LTmin,SMR] = Level_Sound_BC(X,CB, Local, N, LTgM);

            
             scf = 0;
             %X = 0;
             Lsb = 0;
             
          
          
     
       
      



