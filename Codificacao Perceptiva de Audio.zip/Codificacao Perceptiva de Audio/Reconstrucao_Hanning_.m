

%Recomposicao Perceptually Weighted M. P.

clc;
clear all;
disp('In�cio Reconstrucao do Sinal');


load('result_decomp');
Audio_Decomposto = result_decomp;
[Audio_Decompostorow,Audio_Decompostocol] = size(Audio_Decomposto);


load('Initial_Parm');
PARAMETROS_INICIAIS = Initial_Parm;


load('Residue_Final')
Residue_Final;                 
load ('Dens_Sinal_Orig')
Dens_Sinal_Orig;               
load ('Limiar_Sinal_Origi');  
Limiar_Sinal_Origi;


load('IterPorBloco');
ITERACAO = Numer_Blocos_Itera;
[ITERACAOrow,ITERACAOcol] = size(ITERACAO);




[N,M,N_hop,dB,MRT,BA,NBA,BPh,NBPh,s] = Lendo_Parm(Initial_Parm);


L = ceil(length(Audio_Decomposto)/N);
xcell = cell(L,1);



[z,Fs] = audioread('pianoA3.wav');          



 load('zBase');
 z1 = zBase;
 
 zRec=zeros(length(zBase),1);
 y = zRec';

 x_hat1 =zRec';
 x_hat =zRec';
 x_hatA =zRec';
 x_hat1A =zRec';

 
 x =zBase;
 x = x';


w = hanning(N);
W_FFT = fft(w,M)/N;

W0 = W_FFT(1,1);


 PHIKRSAVE = [];
 
 Numero_total_Bits = 0;

for kBlock = 1:Audio_Decompostocol;
    disp(['Bloco: ' num2str(kBlock)]);
    structBook = Audio_Decomposto{1,kBlock};
    length(structBook);
    
    
    a = N_hop*(kBlock-1)+1;   
    b = a+N-1;

     
    AkrMAX = max(structBook(:,1));
    AkrMIN = min(structBook(:,1));
    
    PhikrMAX = max(structBook(:,2));
    PhikrMIN = min(structBook(:,2));
    
 
    
    NITER = ITERACAO(kBlock,1);
    
    %********************************************************************
     Num_Bits_Rec  = (NBA + NBPh + (log2(M/2)));
     Num_Bits_Rec_Of_Bloc = NITER*Num_Bits_Rec;
     Bits_Por_Bloco(kBlock,1) = Num_Bits_Rec_Of_Bloc;
     Numero_total_Bits = Numero_total_Bits + Num_Bits_Rec_Of_Bloc;
     %********************************************************************
       
    Residue = x(a:b);
    
 %***************************************************************************
 %***************************************************************************
 Prod_Point_Point = w'.*(Residue);  %produto interno matricial            
 Rw = fft(Prod_Point_Point)/N;
    
 [LTtM, LTnM, THNM, XM, TqNM, LTgM] = Psychoacoustics_M (Rw,Fs,s);
 %***************************************************************************
 %***************************************************************************  

 Audio_Reconstruido_Nao_Quantizado = 0;
 Audio_Reconstruido_Quantizado = 0;
           
          for km = 1:NITER             %Indice do Somatorio ate a K-esima iteracao maxima;
          %for km = 1:length(structBook) %Indice do Somatorio ate a M maximo;    
                             
              %------------------------------------------------------------
              %-----Lendo Parametros---------------------------------------
               [Akr, Phikr, Xir, IndMax] = Read_Parm(structBook, km);
              %************************************************************
             
              %------------------------------------------------------------
              %-----Reconstruindo o Sinal N�o Quantizado-------------------    
               [Aprox_Reconst] = Signal_Recons(Akr, Phikr, Xir, N, IndMax, M, W0);  
               
               Audio_Reconstruido_Nao_Quantizado = Audio_Reconstruido_Nao_Quantizado + (w'.*Aprox_Reconst);            
              %************************************************************ 
                             
              %------------------------------------------------------------
              %-----Quanrizacao--------------------------------------------
               [AkrQuant, PhikrQuant, XirQuant] = Quantizer(Akr, Phikr, Xir, AkrMAX, AkrMIN, NBA, NBPh, MRT, PhikrMAX, PhikrMIN);
              %************************************************************               
          
              %------------------------------------------------------------
              %-----Reconstruindo o Sinal Com A Quantizado-----------------    
               [Aprox_Reconst_Quantizer] = Signal_Recons_Quantizer(AkrQuant, PhikrQuant, XirQuant, N, IndMax, M, W0);

               Audio_Reconstruido_Quantizado = Audio_Reconstruido_Quantizado + (w'.*Aprox_Reconst_Quantizer);                
              %************************************************************ 
              
              PHIKRSAVE(km,:) = [Phikr PhikrQuant]; % Guarda as fase n�o quantizadas e quantizadas
        
          end 

          x_hat(1,a:b) = x_hat(1,a:b) +  Audio_Reconstruido_Nao_Quantizado; % Soma de cada bloco
          x_hat1(1,a:b) = x_hat1(1,a:b) + Audio_Reconstruido_Quantizado;
         
                        
         
     PHIKRQUANTENAO{1,kBlock} = PHIKRSAVE;
     PHIKRSAVE = [];     
     
end


 y = x_hat;
 yfinal = y(1,N_hop+1:N_hop+length(z));
 
 
 y1 = x_hat1;
 y1final = y1(1,N_hop+1:N_hop+length(z));
 
 
 
 %*********************************************************************
 Delta = z'-y1final;
 EQM = (sum(Delta.^2))/numel(z')
 %*********************************************************************



save ('RecompNaoQuantizado.mat','yfinal');
save('RecompQuantizado.mat','y1final')
 
disp('Por Parametros');
 
figure(kBlock+1)
subplot(2,1,1)    
plot(z');
title('Audio Original');
xlabel('Tempo (s)')
ylabel('Amplitude')
subplot(2,1,2)
plot(yfinal);
title('Audio Reconstruido Nao Quantizado');
title('Audio Reconstruido')
xlabel('Tempo (s)')
ylabel('Amplitude')
saveas(gcf, 'Audio Reconstruido Nao Quantizado','jpg')
 
sound(yfinal,Fs)
audiowrite('AudioReconstruidoNaoQuantizado.wav',yfinal,Fs)
 
figure(kBlock+2)
plot(z'-yfinal)
xlabel('Tempo (s)')
ylabel('Amplitude')
saveas(gcf, 'Erro da reconstrucao nao quantizado','jpg')
sound((z'-yfinal),Fs)
 
audiowrite('Erro da reconstrucao nao quantizado final.wav',(z'-yfinal),Fs)
 
 
 [P,Q] = rat(48000/Fs);
 
 [AUDIO_ROCONSTR_PARAM,Fs] = audioread('AudioReconstruidoNaoQuantizado.wav');
 AudioReconstruidoParametrosnew = resample(AUDIO_ROCONSTR_PARAM,P,Q);
 audiowrite('AudioReconstruidoNaoQuantizado48000.wav',AudioReconstruidoParametrosnew,48000)
 
 
 
disp('Quantizado');
figure(kBlock+3)
subplot(2,1,1)    
plot(z');
title('Audio Original');
xlabel('s')
ylabel('Amplitude')
subplot(2,1,2)
plot(y1final);
title('Audio Reconstruido Quantizado');
xlabel('s')
ylabel('Amplitude')
saveas(gcf, 'Audio Reconstruido Quantizado','jpg')
sound(y1final,Fs)
audiowrite('AudioReconstruidoQuantizadoFinal.wav',y1final,Fs)
 
[AUDIO_ROCONSTR_Quantizado,Fs] = audioread('AudioReconstruidoQuantizadoFinal.wav');
AudioReconstruidoQuantizadoNovo = resample(AUDIO_ROCONSTR_Quantizado,P,Q);
audiowrite('AudioReconsQuantFinal48000.wav',AudioReconstruidoQuantizadoNovo,48000)
 
figure(kBlock+4)
plot(z'-y1final)
title('Erro da reconstrucao Quantizado')
xlabel('s')
ylabel('Amplitude')
saveas(gcf, 'Erro da reconstrucao Quantizado','jpg')
 
sound((z'-y1final),Fs)
 
audiowrite('Erro da reconstrucao Quantizado Final.wav',(z'-y1final),Fs)
  
 
PianoA3new = resample(z,P,Q);
audiowrite('PianoA3New.wav',PianoA3new,48000)
PQevalAudio ('PianoA3New.wav', 'AudioReconsQuantFinal48000.wav')
 
 
disp('Final da Reconstrucao');
 