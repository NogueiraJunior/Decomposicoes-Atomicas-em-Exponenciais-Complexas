function [AkrDisc, PhikrDisc, XirDisc] = Quantizer(Akr, Phikr, Xir, AkrMAX, AkrMIN, BA, BPh, MRT, PhikrMAX, PhikrMIN)

%Para Amplitude
QAkr = ((AkrMAX - AkrMIN) / ((2^BA)-MRT));
IAkr = floor(((Akr + (QAkr/2))/QAkr));
AkrDisc = IAkr*QAkr;

%Para Fase
%QPh = ((PhikrMAX - PhikrMIN) / ((2^BPh)-MRT));
QPh = ((2*pi)/((2^BPh)-MRT));
IPh = floor(((Phikr + (QPh/2))/QPh));
PhikrDisc = IPh*QPh;

%Para Frequencia

XirDisc = Xir;

end

