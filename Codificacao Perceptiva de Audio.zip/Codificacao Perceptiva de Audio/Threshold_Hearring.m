function [Tq,step] = Threshold_Hearring(Fs,N,M)


%for k = 0:M-1
for k = 0:(M/2)-1
    step(1,k+1)= (k*Fs)/M;
end

%for k=1
%    Tq(1,k)=0;
%end

for k = 1:M/2
     % Limite do Silencio
    Tq(1,k) = 3.64*((step(1,k)/1000)^(-8/10))-6.5*exp((-6/10)*(((step(1,k)/1000)-3.3)^2))+(10^(-3))*(((step(1,k)/1000)^4));

end

%Tq= [Tq fliplr(Tq)];



